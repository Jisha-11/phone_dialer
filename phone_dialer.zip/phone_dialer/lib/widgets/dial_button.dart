// lib/widgets/dial_button.dart
import 'package:flutter/material.dart';

class DialButton extends StatelessWidget {
  final String number;
  final VoidCallback onPressed;

  const DialButton({required this.number, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.grey[200],
        ),
        child: Center(
          child: Text(number, style: TextStyle(fontSize: 24)),
        ),
      ),
    );
  }
}