import 'package:flutter/material.dart';
import 'call_screen.dart';

class ContactsScreen extends StatelessWidget {
  final Map<String, List<Contact>> _contacts = {
    'A': [
      Contact(name: 'Alice', number: '123-456-7890'),
      Contact(name: 'Aaron', number: '123-456-7891'),
      Contact(name: 'Amy', number: '123-456-7892'),
    ],
    'B': [
      Contact(name: 'Bob', number: '234-567-8901'),
      Contact(name: 'Beth', number: '234-567-8902'),
      Contact(name: 'Brian', number: '234-567-8903'),
    ],
    'C': [
      Contact(name: 'Charlie', number: '345-678-9012'),
      Contact(name: 'Catherine', number: '345-678-9013'),
      Contact(name: 'Chris', number: '345-678-9014'),
    ],
    'D': [
      Contact(name: 'David', number: '456-789-0123'),
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contacts'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              // Implement search functionality
            },
          ),
        ],
      ),
      body: ListView(
        children: _contacts.entries.map((entry) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  entry.key,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ...entry.value.map((contact) {
                return ListTile(
                  leading: CircleAvatar(
                    child: Text(contact.name[0]),
                  ),
                  title: Text(contact.name),
                  subtitle: Text(contact.number),
                  trailing: IconButton(
                    icon: Icon(Icons.call, color: Colors.green),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => CallScreen(
                            number: contact.number,
                            name: contact.name,
                            isIncoming: false,
                          ),
                        ),
                      );
                    },
                  ),
                  onTap: () {
                    // Show contact details
                  },
                );
              }).toList(),
              Divider(),
            ],
          );
        }).toList(),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          // Add contact functionality
        },
      ),
    );
  }
}

class Contact {
  final String name;
  final String number;

  Contact({required this.name, required this.number});
}