// lib/screens/call_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/call_record.dart';
import '../repositories/call_history_repository.dart';

class CallScreen extends StatefulWidget {
  final String number;
  final String? name;
  final bool isIncoming;

  const CallScreen({
    required this.number,
    this.name,
    required this.isIncoming,
  });

  @override
  _CallScreenState createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  late Timer _timer;
  Duration _callDuration = Duration.zero;
  bool _isCallActive = true;
  bool _isMuted = false;

  @override
  void initState() {
    super.initState();
    if (!widget.isIncoming) {
      _startTimer();
    }
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (_) {
      setState(() => _callDuration += Duration(seconds: 1));
    });
  }

  void _endCall(BuildContext context) {
    _timer.cancel();
    Provider.of<CallHistoryRepository>(context, listen: false).addCall(
      CallRecord(
        number: widget.number,
        name: widget.name,
        timestamp: DateTime.now(),
        duration: _callDuration,
        isIncoming: widget.isIncoming,
        isMissed: !_isCallActive && widget.isIncoming,
      ),
    );
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              children: [
                SizedBox(height: 50),
                Text(widget.name ?? widget.number, style: TextStyle(fontSize: 28)),
                SizedBox(height: 10),
                Text(
                  _isCallActive ? _formatDuration(_callDuration) : 
                  widget.isIncoming ? 'Incoming call' : 'Calling...',
                  style: TextStyle(fontSize: 18),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(bottom: 40.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  if (widget.isIncoming && !_isCallActive)
                    FloatingActionButton(
                      backgroundColor: Colors.green,
                      child: Icon(Icons.call),
                      onPressed: () {
                        setState(() => _isCallActive = true);
                        _startTimer();
                      },
                    ),
                  FloatingActionButton(
                    backgroundColor: Colors.red,
                    child: Icon(Icons.call_end),
                    onPressed: () => _endCall(context),
                  ),
                  if (_isCallActive)
                    FloatingActionButton(
                      child: Icon(_isMuted ? Icons.mic_off : Icons.mic),
                      onPressed: () => setState(() => _isMuted = !_isMuted),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDuration(Duration d) => 
      '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
}