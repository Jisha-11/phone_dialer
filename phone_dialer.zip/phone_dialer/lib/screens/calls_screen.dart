// lib/screens/calls_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/call_record.dart';
import '../repositories/call_history_repository.dart';
import 'call_screen.dart';

class CallsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final callHistory = Provider.of<CallHistoryRepository>(context).callHistory;

    return Scaffold(
      appBar: AppBar(
        title: Text('Call History'),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => Provider.of<CallHistoryRepository>(context, listen: false).clearHistory(),
          ),
        ],
      ),
      body: callHistory.isEmpty
          ? Center(child: Text('No call history'))
          : ListView.builder(
              itemCount: callHistory.length,
              itemBuilder: (context, index) {
                final call = callHistory[index];
                return ListTile(
                  leading: Icon(
                    call.isIncoming 
                      ? call.isMissed ? Icons.call_missed : Icons.call_received 
                      : Icons.call_made,
                    color: call.isMissed ? Colors.red : Colors.green,
                  ),
                  title: Text(call.name ?? call.number),
                  subtitle: Text('${call.formattedDate} • ${_formatDuration(call.duration)}'),
                  trailing: IconButton(
                    icon: Icon(Icons.call, color: Colors.green),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CallScreen(
                          number: call.number,
                          name: call.name,
                          isIncoming: false,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }

  String _formatDuration(Duration d) => 
      d.inSeconds < 60 ? '${d.inSeconds} sec' : '${d.inMinutes} min';
}