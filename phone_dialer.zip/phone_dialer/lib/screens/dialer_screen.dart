// lib/screens/dialer_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../widgets/dial_button.dart';
import 'call_screen.dart';

class DialerScreen extends StatefulWidget {
  @override
  _DialerScreenState createState() => _DialerScreenState();
}

class _DialerScreenState extends State<DialerScreen> {
  String _enteredNumber = '';
  final List<List<String>> _dialPad = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['*', '0', '#'],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dialer')),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: Text(_enteredNumber, style: TextStyle(fontSize: 32)),
            ),
          ),
          Expanded(
            flex: 3,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: _dialPad.map((row) => Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: row.map((number) => DialButton(
                  number: number,
                  onPressed: () => setState(() => _enteredNumber += number),
                )).toList(),
              )).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(Icons.call, color: Colors.green),
                  onPressed: _enteredNumber.isEmpty ? null : () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CallScreen(
                        number: _enteredNumber,
                        isIncoming: false,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.backspace),
                  onPressed: _enteredNumber.isEmpty ? null : () => setState(
                    () => _enteredNumber = _enteredNumber.substring(0, _enteredNumber.length - 1),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}