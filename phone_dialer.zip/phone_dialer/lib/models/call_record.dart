// lib/models/call_record.dart
class CallRecord {
  final String number;
  final String? name;
  final DateTime timestamp;
  final Duration duration;
  final bool isIncoming;
  final bool isMissed;

  CallRecord({
    required this.number,
    this.name,
    required this.timestamp,
    required this.duration,
    required this.isIncoming,
    this.isMissed = false,
  });

  String get formattedDate => '${timestamp.day}/${timestamp.month}/${timestamp.year}';
  String get formattedTime => '${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}';
}