// lib/repositories/call_history_repository.dart
import 'package:flutter/foundation.dart';
import '../models/call_record.dart';

class CallHistoryRepository extends ChangeNotifier {
  final List<CallRecord> _callHistory = [];

  List<CallRecord> get callHistory => List.unmodifiable(_callHistory);

  void addCall(CallRecord record) {
    _callHistory.insert(0, record);
    if (_callHistory.length > 100) {
      _callHistory.removeLast();
    }
    notifyListeners(); // Notify widgets when history changes
  }

  void clearHistory() {
    _callHistory.clear();
    notifyListeners(); // Notify widgets when history changes
  }
}