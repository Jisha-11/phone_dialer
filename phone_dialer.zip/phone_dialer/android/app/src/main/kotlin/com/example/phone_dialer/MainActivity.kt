package com.example.phone_dialer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
